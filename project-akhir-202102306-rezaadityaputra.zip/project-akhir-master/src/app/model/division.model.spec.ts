import { Division } from './division.model';

describe('Division', () => {
  it('should create an instance', () => {
    expect(new Division()).toBeTruthy();
  });
});
